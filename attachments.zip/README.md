Axit template
=============
Axit is a responsive HTML template made with HMTL5, CSS3 and JavaScript. You can see the template live on [axit.petrbazout.cz](http://axit.petrbazout.cz).

Design is from [designscrazed.org](http://designscrazed.org/free-photoshop-psd-website-templates/).